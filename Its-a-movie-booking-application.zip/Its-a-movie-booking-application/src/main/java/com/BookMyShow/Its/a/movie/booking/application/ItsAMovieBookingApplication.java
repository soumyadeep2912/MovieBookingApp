package com.BookMyShow.Its.a.movie.booking.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItsAMovieBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItsAMovieBookingApplication.class, args);
	}

}
