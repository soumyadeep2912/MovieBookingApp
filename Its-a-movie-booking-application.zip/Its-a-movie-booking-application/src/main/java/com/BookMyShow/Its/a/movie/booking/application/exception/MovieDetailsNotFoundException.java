package com.BookMyShow.Its.a.movie.booking.application.exception;

public class MovieDetailsNotFoundException extends Exception{

    public MovieDetailsNotFoundException(String message) {
        super(message);
    }
}
