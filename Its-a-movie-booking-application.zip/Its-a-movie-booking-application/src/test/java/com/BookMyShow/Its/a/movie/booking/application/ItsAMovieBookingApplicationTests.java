package com.BookMyShow.Its.a.movie.booking.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItsAMovieBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
